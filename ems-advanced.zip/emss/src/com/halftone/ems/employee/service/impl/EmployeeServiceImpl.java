package com.halftone.ems.employee.service.impl;

import java.sql.SQLException;
import java.util.List;

import com.halftone.ems.employee.dao.EmployeeDao;
import com.halftone.ems.employee.dao.impl.EmployeeDaoImpl;
import com.halftone.ems.employee.service.EmployeeService;
import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.model.Employee;
import com.halftone.ems.utils.Validator;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao employeeDao = new EmployeeDaoImpl();

	@Override
	public Employee addEmployee(Employee employee) throws InvalidInputException, DatabaseException {

		if (!Validator.checkEmptyOrNull(employee.getFirstName())) {
			throw new InvalidInputException("First name is empty");
		}
		if (!Validator.checkEmptyOrNull(employee.getLastName())) {
			throw new InvalidInputException("First name is empty");
		}

		try {
			return employeeDao.create(employee);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseException("Failed to create employee");
		}
	}

	@Override
	public Employee updateEmployee(Employee employee, Integer id) throws InvalidInputException, DatabaseException {
		if (!Validator.checkEmptyOrNull(employee.getFirstName())) {
			throw new InvalidInputException("First name is empty");
		}
		if (!Validator.checkEmptyOrNull(employee.getLastName())) {
			throw new InvalidInputException("First name is empty");
		}
		try {
			return employeeDao.update(employee, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseException("Failed to update employee");
		}
	}

	@Override
	public Boolean deleteEmployee(Integer id) throws InvalidInputException, DatabaseException {
		try {
			return employeeDao.delete(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseException("Failed to delete employee");
		}
	}

	@Override
	public List<Employee> search(String firstName, String lastName) throws InvalidInputException, DatabaseException {
		try {
			return employeeDao.search(firstName, lastName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseException("Failed to search employee");
		}
	}

	@Override
	public Employee search(Integer id) throws InvalidInputException, DatabaseException {
		try {
			return employeeDao.search(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseException("Failed to search employee");
		}
	}

	@Override
	public List<Employee> listAll() throws InvalidInputException, DatabaseException {
		try {
			return employeeDao.getAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseException("Failed to list employees");
		}
	}

}
