package com.halftone.ems.employee.controller;

import java.util.List;

import com.halftone.ems.employee.service.EmployeeService;
import com.halftone.ems.employee.service.impl.EmployeeServiceImpl;
import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.model.Employee;

public class EmployeeController {
	
	EmployeeService employeeService = new EmployeeServiceImpl();
	
	public Employee createEmployee(Employee employee) throws InvalidInputException, DatabaseException {
		return employeeService.addEmployee(employee);
	}
	
	public Employee editEmployee(Employee employee, Integer id) throws InvalidInputException, DatabaseException {
		return employeeService.updateEmployee(employee, id);
	}
	
	public List<Employee> searchEmployee(String firstName, String lastName) throws InvalidInputException, DatabaseException {
		return employeeService.search(firstName, lastName);
	}
	
	public Employee searchEmployee(Integer employeeId) throws InvalidInputException, DatabaseException {
		return employeeService.search(employeeId);
	}
	
	public Boolean deleteEmployee(Integer id) throws InvalidInputException, DatabaseException {
		return employeeService.deleteEmployee(id);
	}
}
