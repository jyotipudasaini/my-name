package com.halftone.ems.user.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.halftone.ems.model.User;
import com.halftone.ems.user.dao.UserDao;
import com.halftone.ems.utils.DatabaseConnectionUtil;
import com.mysql.jdbc.PreparedStatement;

public class UserDaoImpl implements UserDao {

	@Override
	public Boolean changePassword(User user, String newPassword) throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn
				.prepareStatement("UPDATE user SET password = password(?) where id = ?");
		ps.setString(1, newPassword);
		ps.setInt(2, user.getId());

		ps.executeUpdate();
		return Boolean.TRUE;
	}

	@Override
	public User create(User user) throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn
				.prepareStatement("INSERT INTO user(id, user_name, password, role) VALUES(?, ? , password(?), ?)");
		ps.setInt(1, user.getId());
		ps.setString(2, user.getUserName());
		ps.setString(3, user.getPassword());
		ps.setString(4, user.getRole());
		ps.executeUpdate();
		
		return user;
	}

	@Override
	public User update(User t, Integer e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User delete(Integer e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User search(Integer e) {
		// TODO Auto-generated method stub
		return null;
	}

}
