package com.halftone.ems.user.service;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.model.User;

public interface UserService {
	
	Boolean changePassword(User user, String newPassword) throws DatabaseException, InvalidInputException;
	
	User addUser(User user) throws InvalidInputException, DatabaseException;
}
