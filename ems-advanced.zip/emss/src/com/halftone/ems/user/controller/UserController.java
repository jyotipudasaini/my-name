package com.halftone.ems.user.controller;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.model.Employee;
import com.halftone.ems.model.User;
import com.halftone.ems.user.service.UserService;
import com.halftone.ems.user.service.impl.UserServiceImpl;

public class UserController {

	UserService userService = new UserServiceImpl();

	public Boolean changePassword(User user, String newPassword) throws DatabaseException, InvalidInputException {
		return userService.changePassword(user, newPassword);
	}
	
	public User createUser(User user) throws InvalidInputException, DatabaseException {
		return userService.addUser(user);
	}
}
