package com.halftone.ems.dao;

import java.sql.SQLException;
import java.util.List;

public interface GenericDao<T, E> {
	/**
	 * This method is used to create a record in Database
	 * @param t
	 * @return
	 * @throws SQLException 
	 */
	T create(T t) throws SQLException;
	
	/**
	 * This method is used to update record in Database
	 * @param t
	 * @param e
	 * @return
	 * @throws SQLException 
	 */
	T update(T t, E e) throws SQLException;
	
	/**
	 * This method is used to delete a record in Database
	 * @param e
	 * @return
	 * @throws SQLException 
	 */
	Boolean delete(E e) throws SQLException;
	
	/**
	 * Retrieves all the records from DB
	 * @return
	 * @throws SQLException 
	 */
	List<T> getAll() throws SQLException;
	
	/**
	 * Search for a specific record
	 * @param e
	 * @return
	 * @throws SQLException 
	 */
	T search(E e) throws SQLException;
	
}
