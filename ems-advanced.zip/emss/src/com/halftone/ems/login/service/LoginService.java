package com.halftone.ems.login.service;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.model.User;

public interface LoginService {
	
	/**
	 * This method checks whether a user name is present in the system or now
	 * @param userName
	 * @return {@link Boolean} True if present else false
	 * @throws DatabaseException 
	 * @throws InvalidInputException 
	 */
	Boolean verifyUserName(String userName) throws InvalidInputException, DatabaseException;
	
	/**
	 * Login to the system with given username and password
	 * @param userName
	 * @param password
	 * @return {@link Boolean} True if login is successful else false
	 * @throws InvalidInputException 
	 * @throws DatabaseException 
	 */
	User login (String userName, String password) throws InvalidInputException, DatabaseException;
	
}
