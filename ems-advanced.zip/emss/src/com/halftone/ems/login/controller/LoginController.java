package com.halftone.ems.login.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.login.service.LoginService;
import com.halftone.ems.login.service.impl.LoginServiceImpl;
import com.halftone.ems.model.User;

public class LoginController extends HttpServlet {

	LoginService loginService = new LoginServiceImpl();

	public Boolean verifyUserName(String userName) throws InvalidInputException, DatabaseException {
		return loginService.verifyUserName(userName);
	}

	public User login(String userName, String password) throws InvalidInputException, DatabaseException {
		User user = loginService.login(userName, password);
		return user;
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		System.out.println("Inside login contriller");
		User user = null;
		
		try {
			login(userName, password);
		} catch (InvalidInputException | DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.getWriter().append("Login Failed");
	}
	
	
}
