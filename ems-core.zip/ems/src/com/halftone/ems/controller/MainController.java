package com.halftone.ems.controller;

import java.io.Console;
import java.util.List;
import java.util.Scanner;

import com.halftone.ems.employee.controller.EmployeeController;
import com.halftone.ems.enums.Gender;
import com.halftone.ems.enums.UserRole;
import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.login.controller.LoginController;
import com.halftone.ems.model.Employee;
import com.halftone.ems.model.User;
import com.halftone.ems.user.controller.UserController;

public class MainController {

	LoginController loginController = new LoginController();
	UserController userController = new UserController();
	EmployeeController employeeController = new EmployeeController();

	public static void main(String[] args) {
		MainController mainController = new MainController();
		Scanner sc = new Scanner(System.in);
		Console console = System.console();
		abc: for (;;) {
			// clearConsole();
			User user = null;
			System.out.flush();
			System.out.println("\t\t\t\t\t Welcome To Employee Management System \n\n\n");

			Boolean something = Boolean.FALSE;
			something = !something;
			for (;;) {
				try {
					System.out.print("\n\nEnter username::");
					String userName = null;
					if (!sc.hasNextLine()) {
						continue;
					}
					userName = sc.nextLine();
					if (userName.isEmpty())
						continue;
					if (!mainController.loginController.verifyUserName(userName)) {
						System.out.println("User name is not present. Login Failed.");
						continue;
					}
					System.out.println("Enter password::");
					// char[] pass = console.readPassword("Password::");
					// String password = new String(pass);
					String password = null;
					if (sc.hasNext()) {
						password = sc.nextLine();
					}

					user = mainController.loginController.login(userName, password);

					if (user != null && user.getId() != null) {
						System.out.println("Login Successful.");
						System.out.printf("Welcome back %s", userName);
					} else {
						System.out.println("Login Failed. Try again later");
						continue;
					}
					break;
				} catch (InvalidInputException | DatabaseException e1) {
					e1.printStackTrace();
					System.out.println("\n\n\n\n\n");
					sc.nextLine();
				}
			}

			for (;;) {
				try {
					int option;
					if (UserRole.ADMIN.getRole().equalsIgnoreCase(user.getRole())) {
						for (;;) {
							// clearConsole();
							System.out.println("\n\n");
							System.out.println("1. Add Employee \t\t\t 2. Edit Employee \t\t\t");
							System.out.println("3. Delete Employee \t\t\t 4. Search Employee \t\t\t");
							System.out.println("5. Add Attendance \t\t\t 6. Edit Attendance \t\t\t");
							System.out.println("7. Change Password");
							System.out.println("8. Logout");
							System.out.println("Select an option");
							option = sc.nextInt();
							if (option == 8)
								continue abc;
							mainController.handleOptions(user, option, sc);
						}
					} else if (UserRole.USER.getRole().equalsIgnoreCase(user.getRole())) {
						for (;;) {
							// clearConsole();
							System.out.println("\n\n");
							System.out.println("1. Edit Personal Information");
							System.out.println("2. Search Employee");
							System.out.println("3. Add Attendance");
							System.out.println("4. Change Password");
							System.out.println("5. Logout");
							System.out.println("Select an option");
							option = sc.nextInt();
							if (option == 5)
								continue abc;
							mainController.handleOptions(user, option, sc);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					sc.nextLine();
				}
			}

		}

	}

	public void handleOptions(User user, int option, Scanner sc) {
		if (UserRole.ADMIN.getRole().equalsIgnoreCase(user.getRole())) {
			switch (option) {
			case 1:
				try {
					addEmployee(sc);
				} catch (InvalidInputException e) {
					e.printStackTrace();
				} catch (DatabaseException e) {
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					editEmployee(sc);
				} catch (InvalidInputException e) {
					e.printStackTrace();
				} catch (DatabaseException e) {
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					deleteEmployee(sc);
				} catch (InvalidInputException e) {
					e.printStackTrace();
				} catch (DatabaseException e) {
					e.printStackTrace();
				}
				
				break;
			case 4:
				try {
					searchEmployee(sc);
				} catch (InvalidInputException | DatabaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case 7:
				changePassword(user, sc);
				break;
			default:
				System.out.println("Invalid Option");
				break;
			}
		} else if (UserRole.USER.getRole().equalsIgnoreCase(user.getRole())) {
			switch (option) {
			case 1:
				try {
					editEmployee(sc, user);
				} catch (InvalidInputException | DatabaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					searchEmployee(sc);
				} catch (InvalidInputException | DatabaseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				changePassword(user, sc);
				break;
			default:
				System.out.println("Invalid Option");
				break;
			}
		}
	}
	
	public void editEmployee(Scanner sc, User user) throws InvalidInputException, DatabaseException {
		Employee employee = inputEmployeeData(sc);
		employeeController.editEmployee(employee, user.getId());
		System.out.println("Successfully changed information");
	}
	
	// For admini
	public void editEmployee(Scanner sc) throws InvalidInputException, DatabaseException {
		List<Employee> employees = searchEmployee(sc);
		if (employees.size() < 1) {
			return;
		}
		System.out.println("\n\nEnter id to delete::");
		Integer id = sc.nextInt();
		Boolean matches = false;
		Employee employeeToBeEdited = null;
		for (Employee employee : employees) {
			if (id == employee.getId()) {
				matches = true;
				employeeToBeEdited = employee;
				break;
			}
		}
		if (!matches) {
			System.out.println("\nInvalid employee id. Id not present in the list");
			return;
		}

		System.out.printf("Id: %d \tFirstname: %s \tLastname: %s \tGender: %s \tAge: %d \tPhonenumber: %s",
				employeeToBeEdited.getId(), employeeToBeEdited.getFirstName(), employeeToBeEdited.getLastName(),
				employeeToBeEdited.getSex().getGender(), employeeToBeEdited.getAge(),
				employeeToBeEdited.getPhoneNumber());

		Employee employee = inputEmployeeData(sc);
		employeeController.editEmployee(employee, employeeToBeEdited.getId());
	}

	public void deleteEmployee(Scanner sc) throws InvalidInputException, DatabaseException {
		List<Employee> employees = searchEmployee(sc);
		if (employees.size() < 1) {
			return;
		}
		System.out.println("\n\nEnter id to delete::");
		Integer id = sc.nextInt();
		Boolean matches = false;
		for (Employee employee : employees) {
			if (id == employee.getId()) {
				matches = true;
				break;
			}
		}
		if (!matches) {
			System.out.println("\nInvalid employee id. Id not present in the list");
			return;
		}
		employeeController.deleteEmployee(id);
		System.out.println("\n Employee Deleted Successfully");
	}

	public void changePassword(User user, Scanner sc) {
		System.out.println("Enter password::");
		String password1 = sc.next();
		System.out.println("\nRe-enter password::");
		String password2 = sc.next();
		if (password1.equals(password2)) {
			try {
				Boolean result = userController.changePassword(user, password1);
				if (result == Boolean.TRUE) {
					System.out.println("Password successfully changed!!!");
				}
			} catch (DatabaseException e) {
				e.printStackTrace();
			} catch (InvalidInputException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Invalid password. Passwords do not match");
		}
	}

	public void addEmployee(Scanner sc) throws InvalidInputException, DatabaseException {
		Employee employee = inputEmployeeData(sc);
		employee = employeeController.createEmployee(employee);
		System.out.println("After saving...");
		System.out.println(employee);

		User user = inputUserData(sc);
		user.setId(employee.getId());
		userController.createUser(user);
		System.out.println("Successfully created an employee");
	}

	public Employee inputEmployeeData(Scanner sc) {
		Employee employee = inputEmployeeSearchParams(sc);

		System.out.println("Enter middle name::");
		String middleName = sc.nextLine();

		System.out.println("Enter phone number::");
		String phoneNumber = sc.nextLine();

		System.out.println("Enter age::");
		Integer age = sc.nextInt();

		Integer genderOption;
		for (;;) {
			System.out.println("Select Sex::");
			System.out.println("1. Female \t\t 2. Male \t\t 3. Others");
			System.out.println("Select number..");
			genderOption = sc.nextInt();
			if (!validateField(genderOption)) {
				System.out.println("This is a required field. Hence can't be empty");
				continue;
			}
			break;
		}

		Gender gender = Gender.searchGender(genderOption);
		employee.setAge(age);
		employee.setMiddleName(middleName);
		employee.setSex(gender);
		employee.setPhoneNumber(phoneNumber);
		System.out.println(employee);
		return employee;
	}

	public User inputUserData(Scanner sc) {
		String userName;
		for (;;) {
			System.out.println("Enter username::");
			userName = sc.nextLine();
			if (!validateField(userName.trim())) {
				System.out.println("This is a required field. Hence can't be empty");
				continue;
			}
			break;
		}

		String password;
		for (;;) {
			System.out.println("Enter password::");
			password = sc.nextLine();
			if (!validateField(password.trim())) {
				System.out.println("This is a required field. Hence can't be empty");
				continue;
			}
			break;
		}

		Integer role;
		for (;;) {
			System.out.println("Select Role::");
			System.out.println("1. Admin \t\t 2. User");
			System.out.println("Select number..");
			role = sc.nextInt();
			if (!validateField(role)) {
				System.out.println("This is a required field. Hence can't be empty");
				continue;
			}
			break;
		}
		UserRole userRole = UserRole.searchRole(role);

		User user = new User();
		user.setRole(userRole.getRole());
		user.setUserName(userName);
		user.setPassword(password);
		return user;
	}

	public Employee inputEmployeeSearchParams(Scanner sc) {
		Employee employee = new Employee();
		String firstName;
		for (;;) {
			System.out.println("Enter first name::");
			firstName = sc.nextLine();
			if (!validateField(firstName.trim())) {
				System.out.println("This is a required field. Hence can't be empty");
				continue;
			}
			break;
		}

		employee.setFirstName(firstName);

		String lastName;
		for (;;) {
			System.out.println("Enter last name::");
			lastName = sc.nextLine();
			if (!validateField(lastName.trim())) {
				System.out.println("This is a required field. Hence can't be empty");
				continue;
			}
			break;
		}
		employee.setLastName(lastName);
		return employee;
	}

	public List<Employee> searchEmployee(Scanner sc) throws InvalidInputException, DatabaseException {
		Employee employee = inputEmployeeSearchParams(sc);
		List<Employee> employees = employeeController.searchEmployee(employee.getFirstName(), employee.getLastName());
		if (employees.size() > 0) {
			System.out.println("\n\n\n");
			for (Employee em : employees) {
				System.out.printf("Id: %d \t Name: %s \t Phone: %s \t Age: %d \t Sex: %s \t Is Retired: %b", em.getId(),
						em.getFirstName() + " " + em.getLastName(), em.getPhoneNumber(), em.getAge(),
						em.getSex().getGender(), em.getIsRetired());
			}
		} else {
			System.out.println("\n\n\n No employee Found");
		}
		return employees;
	}

	public Boolean validateField(String fieldValue) {
		if (fieldValue == null || fieldValue.isEmpty()) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	public Boolean validateField(Integer fieldValue) {
		if (fieldValue == null) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	public final static void clearConsole() {
		try {
			final String os = System.getProperty("os.name");
			System.out.println("os::" + os);
			if (os.contains("Windows")) {
				Runtime.getRuntime().exec("cls");
			} else {
				System.out.println("hereree");
				Runtime.getRuntime().exec("ls");
				Runtime.getRuntime().exec("clear");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
