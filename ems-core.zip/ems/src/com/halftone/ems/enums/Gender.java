package com.halftone.ems.enums;

public enum Gender {

	FEMALE("female", 1), MALE("male", 2), OTHERS("Others", 3);

	String gender;
	Integer index;

	Gender(String gender, Integer index) {
		this.gender = gender;
		this.index = index;
	}

	public String getGender() {
		return this.gender;
	}

	public Integer getIndex() {
		return this.index;
	}

	public static Gender searchGender(Integer index) {
		Gender result = null;
		for (Gender gender : Gender.values()) {
			if (gender.getIndex() == index) {
				result = gender;
				break;
			}
		}
		return result;
	}
	
	public static Gender searchGender(String genderValue) {
		Gender result = null;
		for (Gender gender : Gender.values()) {
			if (gender.getGender().equals(genderValue)) {
				result = gender;
				break;
			}
		}
		return result;
	}
}
