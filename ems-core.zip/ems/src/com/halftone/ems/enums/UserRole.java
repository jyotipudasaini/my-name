package com.halftone.ems.enums;

public enum UserRole {
	ADMIN("admin", 1), USER("user", 2);

	String role;
	Integer index;

	UserRole(String role, Integer index) {
		this.role = role;
		this.index = index;
	}

	public String getRole() {
		return this.role;
	}

	public Integer getIndex() {
		return this.index;
	}
	
	public static UserRole searchRole(Integer index) {
		UserRole result = null;
		for (UserRole userRole : UserRole.values()) {
			if (userRole.getIndex() == index) {
				result = userRole;
				break;
			}
		}
		return result;
	}
}
