package com.halftone.ems.exceptions;

public class DatabaseException extends Exception {

	private static final long serialVersionUID = 7679241350326655184L;
	
	public DatabaseException() {
		super();
	}
	
	public DatabaseException(String message) {
		super(message);
	}
	
}
 