package com.halftone.ems.login.controller;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.login.service.LoginService;
import com.halftone.ems.login.service.impl.LoginServiceImpl;
import com.halftone.ems.model.User;

public class LoginController {

	LoginService loginService = new LoginServiceImpl();

	public Boolean verifyUserName(String userName) throws InvalidInputException, DatabaseException {
		return loginService.verifyUserName(userName);
	}

	public User login(String userName, String password) throws InvalidInputException, DatabaseException {
		User user = loginService.login(userName, password);
		return user;
	}
	
}
