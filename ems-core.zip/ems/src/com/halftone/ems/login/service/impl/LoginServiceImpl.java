package com.halftone.ems.login.service.impl;

import java.sql.SQLException;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.login.dao.LoginDao;
import com.halftone.ems.login.dao.impl.LoginDaoImpl;
import com.halftone.ems.login.service.LoginService;
import com.halftone.ems.model.User;

public class LoginServiceImpl implements LoginService {

	LoginDao loginDao = new LoginDaoImpl();

	@Override
	public Boolean verifyUserName(String userName) throws InvalidInputException, DatabaseException {
		if (userName == null || userName.isEmpty()) {
			throw new InvalidInputException("Username is empty");
		}
		try {
			return loginDao.verifyUserName(userName);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DatabaseException("Some error while connecting to database.");
		}
	}

	@Override
	public User login(String userName, String password) throws InvalidInputException, DatabaseException {
		if (userName == null || userName.isEmpty()) {
			throw new InvalidInputException("Username is empty");
		}
		if (password == null || password.isEmpty()) {
			throw new InvalidInputException("Password can't be empty");
		}
		try {
			return loginDao.login(userName, password);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DatabaseException("Some error while connecting to database.");
		}
	}

}
