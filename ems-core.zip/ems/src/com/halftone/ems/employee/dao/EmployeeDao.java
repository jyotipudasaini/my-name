package com.halftone.ems.employee.dao;

import java.sql.SQLException;
import java.util.List;

import com.halftone.ems.dao.GenericDao;
import com.halftone.ems.model.Employee;

public interface EmployeeDao  extends GenericDao<Employee, Integer>{
	
	List<Employee> search(String firstName, String lastName) throws SQLException; 
}
