package com.halftone.ems.employee.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.halftone.ems.employee.dao.EmployeeDao;
import com.halftone.ems.enums.Gender;
import com.halftone.ems.model.Employee;
import com.halftone.ems.utils.DatabaseConnectionUtil;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public Employee create(Employee employee) throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn.prepareStatement(
				"INSERT INTO employee (first_name, middle_name, last_name, age, sex, phone_number, is_retired) VALUES (?, ?, ? , ? ,? ,?, ?)");
		
		ps.setString(1, employee.getFirstName());
		ps.setString(2, employee.getMiddleName());
		ps.setString(3, employee.getLastName());
		ps.setInt(4, employee.getAge());
		ps.setString(5, employee.getSex().getGender());
		ps.setString(6, employee.getPhoneNumber());
		ps.setBoolean(7, Boolean.FALSE);
		
		ps.executeUpdate();
		
		ps.close();
		ps = (PreparedStatement) conn.prepareStatement(
				"SELECT LAST_INSERT_ID()");
		ResultSet rs = ps.executeQuery();
		Integer id = null;
		while(rs.next()) {
			id = rs.getInt(1);
		}
		employee.setId(id);
		System.out.println("employee in dao="+employee);
		
		return employee;
	}

	@Override
	public Employee update(Employee employee, Integer id) throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn.prepareStatement(
				"UPDATE employee set first_name = ?, middle_name = ?, last_name =?, age =?, sex =?, phone_number =?  WHERE id = ?");
		
		ps.setString(1, employee.getFirstName());
		ps.setString(2, employee.getMiddleName());
		ps.setString(3, employee.getLastName());
		ps.setInt(4, employee.getAge());
		ps.setString(5, employee.getSex().getGender());
		ps.setString(6, employee.getPhoneNumber());
		ps.setInt(7, id);
		
		ps.executeUpdate();
		return employee;
	}

	@Override
	public Boolean delete(Integer id) throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn.prepareStatement(
				"UPDATE employee set is_retired = ? WHERE id = ?");
		
		ps.setBoolean(1, Boolean.TRUE);
		ps.setInt(2, id);
		ps.executeUpdate();
		
		return Boolean.TRUE;
	}

	@Override
	public Employee search(Integer id) throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn.prepareStatement(
				"SELECT * FROM employee WHERE id = ?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		Employee employee = new Employee();
		while(rs.next()) {
			employee.setId(rs.getInt(1));
			employee.setFirstName(rs.getString(2));
		}
		
		return employee;
	}

	@Override
	public List<Employee> getAll() throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn.prepareStatement(
				"SELECT * FROM employee");
		ResultSet rs = ps.executeQuery();
		
		List<Employee> employees = new ArrayList<>();
		
		while(rs.next()) {
			Employee employee = new Employee();
			employee.setId(rs.getInt(1));
			employee.setFirstName(rs.getString(2));
			employee.setLastName(rs.getString(3));
			employee.setMiddleName(rs.getString(4));
			employee.setPhoneNumber(rs.getString(5));
			employee.setAge(rs.getInt(6));
			employee.setSex(Gender.searchGender(rs.getString(7)));
			employee.setIsRetired(rs.getBoolean(8));
			
			employees.add(employee);
		}
		
		return employees;
	}

	@Override
	public List<Employee> search(String firstName, String lastName) throws SQLException {
		Connection conn = DatabaseConnectionUtil.getSqlConnection();
		PreparedStatement ps = (PreparedStatement) conn.prepareStatement(
				"SELECT * FROM employee WHERE first_name LIKE ? AND last_name LIKE ?");
		ps.setString(1, "%"+firstName+"%");
		ps.setString(2, lastName);
		
		ResultSet rs = ps.executeQuery();
		
		List<Employee> employees = new ArrayList<>();
		
		while(rs.next()) {
			Employee employee = new Employee();
			employee.setId(rs.getInt(1));
			employee.setFirstName(rs.getString(2));
			employee.setLastName(rs.getString(3));
			employee.setMiddleName(rs.getString(4));
			employee.setPhoneNumber(rs.getString(5));
			employee.setAge(rs.getInt(6));
			employee.setSex(Gender.searchGender(rs.getString(7)));
			employee.setIsRetired(rs.getBoolean(8));
			
			employees.add(employee);
		}
		return employees;
	}

}
