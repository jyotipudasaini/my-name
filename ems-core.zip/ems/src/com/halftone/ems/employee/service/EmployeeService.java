package com.halftone.ems.employee.service;

import java.util.List;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.model.Employee;

public interface EmployeeService {

	Employee addEmployee(Employee employee) throws InvalidInputException, DatabaseException;

	Employee updateEmployee(Employee employee, Integer id) throws InvalidInputException, DatabaseException;

	Boolean deleteEmployee(Integer id) throws InvalidInputException, DatabaseException;

	List<Employee> search(String firstName, String lastName) throws InvalidInputException, DatabaseException;

	Employee search(Integer id) throws InvalidInputException, DatabaseException;
	
	List<Employee> listAll() throws InvalidInputException, DatabaseException;
	
}
