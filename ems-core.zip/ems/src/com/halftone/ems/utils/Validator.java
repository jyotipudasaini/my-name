package com.halftone.ems.utils;

public class Validator {

	public static Boolean checkEmptyOrNull(Integer fieldValue) {
		if (fieldValue == null) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}

	public static Boolean checkEmptyOrNull(String fieldValue) {
		if (fieldValue == null || fieldValue.isEmpty()) {
			return Boolean.FALSE;
		}
		return Boolean.TRUE;
	}
}
