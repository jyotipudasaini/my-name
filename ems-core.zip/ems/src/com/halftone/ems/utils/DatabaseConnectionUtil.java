package com.halftone.ems.utils;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class DatabaseConnectionUtil {
	
	public static Connection getSqlConnection() throws SQLException {
		Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/ems", "root",
				"password");

		return conn;
	}
}
