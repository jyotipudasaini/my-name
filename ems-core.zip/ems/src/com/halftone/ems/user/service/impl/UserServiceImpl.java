package com.halftone.ems.user.service.impl;

import java.sql.SQLException;

import com.halftone.ems.exceptions.DatabaseException;
import com.halftone.ems.exceptions.InvalidInputException;
import com.halftone.ems.model.User;
import com.halftone.ems.user.dao.UserDao;
import com.halftone.ems.user.dao.impl.UserDaoImpl;
import com.halftone.ems.user.service.UserService;
import com.halftone.ems.utils.Validator;

public class UserServiceImpl implements UserService {
	
	UserDao userDao = new UserDaoImpl();
	
	@Override
	public Boolean changePassword(User user, String newPassword) throws DatabaseException, InvalidInputException {
		if (newPassword == null || newPassword.isEmpty()) {
			throw new InvalidInputException("Password is empty");
		}
		try {
			return userDao.changePassword(user, newPassword);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DatabaseException("Failed to change password");
		}
	}

	@Override
	public User addUser(User user) throws InvalidInputException, DatabaseException {
		if (!Validator.checkEmptyOrNull(user.getPassword())) {
			throw new InvalidInputException("Password is empty");
		}
		if (!Validator.checkEmptyOrNull(user.getUserName())) {
			throw new InvalidInputException("Username is empty");
		}
		if (!Validator.checkEmptyOrNull(user.getRole())) {
			throw new InvalidInputException("Role is empty");
		}
		try {
			return userDao.create(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new DatabaseException("Failed to create user");
		}
	}

}
