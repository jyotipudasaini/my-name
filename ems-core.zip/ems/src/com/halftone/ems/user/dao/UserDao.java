package com.halftone.ems.user.dao;

import java.sql.SQLException;

import com.halftone.ems.dao.GenericDao;
import com.halftone.ems.model.User;

public interface UserDao extends GenericDao<User, Integer> {

	Boolean changePassword(User user, String newPassword) throws SQLException;

}
